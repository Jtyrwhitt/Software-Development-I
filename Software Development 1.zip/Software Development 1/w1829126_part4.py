# I declare that my work contains no  examples of misconduct, such as plagiarism, or collusion.
# Any code taken from other sources is referenced within my code solution

# Student ID: w1829126
# Date: 23/11/2022
histogramProg = {"progress": 0,                                                                             # Histogram dictionary to store inputted data
             "trailer": 0,
             "retriever": 0,
             "excluded": 0,
             "total":0
             }
inputNumber = []                                                                                            # Store inputted data in list

part3 = open("part3.txt","w")                                                                               # Opens and creates a file called part3.txt and is writable 

part4 = {}                                                                                                  # Empty dictionary to store student Id and pass, defer, fail credits 

def progression(pas, defer, fail):                                                                          # Function to calculate what student gets 
    progress = ["Progress","Module trailer","Module retriever","Exclude"]
    
    if pas == 120:
        result = progress[0]
        histogramProg["progress"] += 1
        histogramProg["total"] += 1
        inputNumber.append("Progress") 

    elif fail == 20 and pas == 100 or pas == 100 and defer == 20:
        result = progress[1]
        histogramProg["trailer"] += 1
        histogramProg["total"] += 1
        inputNumber.append("Module trailer")
        
    elif fail >= 80:
        result = progress[3]
        histogramProg["excluded"] += 1
        histogramProg["total"] += 1
        inputNumber.append("Exclude")

    elif pas < 80 and defer <= 20:
        result = progress[2]
        histogramProg["retriever"] += 1
        histogramProg["total"] += 1
        inputNumber.append("Module retriever")

    else:
        result = progress[2]
        histogramProg["retriever"] += 1
        histogramProg["total"] += 1
        inputNumber.append("Module retriever")
    return result

while True:                                                                                                 # Loop to input student score and other validations
    student = input("Enter student ID: ").lower()
    if student[0] != "w" or len(student) != 8:                                                              # Checks inputted student Id starts with a w and is 8 characters in length 
        print("Student ID have to start with w and be 8 characters in length \n")
        continue
    
    try:                                                                                                    # Uses try and except to make sure inputted number is an integer
        score = [0, 20, 40, 60, 80, 100, 120]

        pas = int(input("Please enter your total pass credits: "))   
        if pas not in score:                                                                                # If inputted number is not in score then displays out of range and restarts 
           print("Out of range.\n")
           continue

        defer = int(input("Please enter your total defer credits: "))
        if defer not in score:                                                                              # If inputted number is not in score then displays out of range and restarts 
           print("Out of range.\n")
           continue

        fail = int(input("Please enter your total fail credits: "))
        if fail not in score:                                                                               # If inputted number is not in score then displays out of range and restarts 
           print("Out of range.\n")
           continue

        total = pas + defer + fail
        if total != 120:                                                                                    # If the total from pas, defer and fail do not equal 120 then displays Total incorrect
            print("Total incorrect.\n")
            continue
        else:
            progres = progression(pas, defer, fail)
            print(progres,"\n")
        inputNumber.append(pas)
        inputNumber.append(defer)
        inputNumber.append(fail)

        content = [progres," - ",str(pas),", ",str(defer),", ",str(fail),"\n"]                                                      # Formats the pass, defer, fail credits for the end of part 3
        part3.writelines(content)                                                                                                   # Writes the variable content into a text file 
        part4.update({student:[pas,defer,fail]})                                                                                    # Store student variable at the key and pass, defer, fail as the values

        cont = input("Would you like to enter another set of data?\nEnter 'y' for yes or 'q' to quit and view results: ").lower()   # Ask the user if they want to input more data
        if cont == "y":
            print("\n")
            continue
        else:
            break
      
    except ValueError:
        print("Integer required\n")
        continue
part3.close()                                                                         # Closes part3.txt file 

def histogram():  
    print("-" * 80)                                                                                                                             # Display Histogram
    print(f"Histogram\nProgress {histogramProg['progress']}  : ",histogramProg['progress']*"*")
    print(f"Trailer {histogramProg['trailer']}   : ",histogramProg['trailer']*"*")
    print(f"Retriever {histogramProg['retriever']} : ",histogramProg['retriever']*"*")
    print(f"Excluded {histogramProg['excluded']}  : ",histogramProg['excluded']*"*")
    print(f"\n{histogramProg['total']} outcome(s) in total.")
    print("-" * 80)

def part2():
    count = 0                                                                                                                               # Display inputted data
    print("Part 2:")
    for i in range(histogramProg['total']):  
        print(f"{inputNumber[count]} - {inputNumber[count+1]}, {inputNumber[count+2]}, {inputNumber[count+3]}")
        count += 4

def part_3():
    part3 = open("part3.txt","r")               # Opens part3.txt as readable in a variable called part 3
    print("\n"+"Part 3:"+"\n"+part3.read())     # Displays contents in text file part3.txt                      https://www.geeksforgeeks.org/reading-writing-text-files-python/
    part3.close()                               # Closes part3.txt again

  
def part_4():
    print("Part 4:")                                                                                    
    for studentId in part4:                                                                             # Creates a for loop for every student Id Key there is in the part4 dictionary
        print(f"{studentId} : {part4[studentId][0]}, {part4[studentId][1]}, {part4[studentId][2]}")      

def main():
    histogram()
    part2()
    part_3()
    part_4()
main()

    

